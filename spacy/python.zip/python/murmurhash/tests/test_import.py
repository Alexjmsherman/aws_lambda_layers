import murmurhash.mrmr

def test_import():
    assert murmurhash.mrmr
