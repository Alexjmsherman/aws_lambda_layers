
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.5.0'
version = '1.5.0'
full_version = '1.5.0'
git_revision = '4c0fd79391e3b2ec2738bf85bb5dab366dcd12e4'
release = True

if not release:
    version = full_version
